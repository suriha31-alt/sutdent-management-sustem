package com.examples.studmanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudmanagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudmanagementApplication.class, args);
	}

}
