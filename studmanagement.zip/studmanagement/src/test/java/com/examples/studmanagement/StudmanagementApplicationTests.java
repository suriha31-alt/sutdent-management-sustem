package com.examples.studmanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudmanagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
